//test data - replace with json from API
var data = [{
    "id": 0,
    "ticketNo": "201909280001",
    "categoryType": "Road Infrastructure",
    "issue": "Lubak na kalsada",
    "details": "Dahil sa lubak na kalsada dito sa st dominic sobra na dami traffic",
    "imagePath": "image",
    "timeOfOccurence": null,
    "citizen": "Alisa Jackson",
    "municipal": "Bacoor",
    "status": "New",
    "govAssigned": null,
    "govCause": null,
    "govEstimateStart": null,
    "govEstimateEnd": null,
    "citizenConfirmed": false,
    "duplicate": false,
    "parentId": 0,
    "remarks": null
  },
  {
    "id": 1,
    "ticketNo": "201909280002",
    "categoryType": "Transportation",
    "issue": "Baclaran Jeepney Strike",
    "details": "Walang masakyan",
    "imagePath": "image",
    "timeOfOccurence": null,
    "citizen": "Alisa Jackson",
    "municipal": "Bacoor",
    "status": "New",
    "govAssigned": null,
    "govCause": null,
    "govEstimateStart": null,
    "govEstimateEnd": null,
    "citizenConfirmed": false,
    "duplicate": false,
    "parentId": 0,
    "remarks": null
  }];
  //test index == number of returned data
  var testIndex = 10;
function addData(id){
    var table = document.getElementById(id);
    var data1 = "test";
    //change with foreach when actual data is available
    for(var x = 0; x <= testIndex + 1;x++){
        $("#tickets tbody").append("<tr></tr>");
        $("#tickets > tbody > tr:last").append(
            "<a href=''><td>"+ data[x].ticketNo +"</td></a>" +
            "<td>"+ data[x].categoryType +"</td>" +
            "<td>"+ data[x].issue +"</td>"+
            "<td>"+ data[x].details+"</td>" +
            "<td>"+ data[x].timeOfOccurence+"</td>" +
            "<td>"+ data[x].citizen+"</td>" +
            "<td>"+ data[x].municipal+"</td>" +
            "<td>"+ data[x].status+"</td>" +
            "<td>"+ data[x].govAssigned+"</td>" +
            "<td>"+ data[x].govCause+"</td>"+
            "<td>"+ data[x].govEstimateStart+"</td>"+
            "<td>"+ data[x].govEstimateStart+"</td>" 
        );
    }
}

function populate(){

}
