// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import VueLocalStorage from 'vue-localstorage'
import VueToastr2 from 'vue-toastr-2'
import 'vue-toastr-2/dist/vue-toastr-2.min.css'
import Datepicker from 'vuejs-datepicker'
import VueTimepicker from 'vue2-timepicker'
import enflowsumoselect from 'enflow-sumoselect'
import vSelect from 'vue-select'
import Multiselect from 'vue-multiselect'
import VueCurrencyFilter from 'vue-currency-filter'
Vue.component('multiselect', Multiselect)
// vue material
Vue.use(enflowsumoselect)
window.toastr = require('toastr')
Vue.use(VueToastr2)
Vue.use(VueLocalStorage)
Vue.use(Datepicker)
Vue.use(VueTimepicker)
Vue.component('v-select', vSelect)
require('./assets/css/HRMS-MaterialDesign.css')
require('./assets/css/Home.css')
require('./assets/css/vue-select.css')
require('./assets/js/Home.js')

// Or you can specify any other name and use it via this.$ls, this.$whatEverYouWant
Vue.use(VueLocalStorage, {
  name: 'ls',
  bind: true //created computed members from your variable declarations
})
Vue.localStorage.set('URL', 'https://ws.durusthr.com/ilm_ws_live/');
// Vue.localStorage.set('URL', ' http://192.168.2.33:82/');
Vue.localStorage.set('URLnodemailer','http://192.168.2.30:3000/');

import 'bootstrap/dist/css/bootstrap.min.css'
// import 'bootstrap/dist/js/bootstrap.min.js'

Vue.config.productionTip = false


// CURRENCY FORMAT
Vue.use(VueCurrencyFilter,
  {
    symbol : '',
    thousandsSeparator: ',',
    fractionCount: '',
    fractionSeparator: '.',
    symbolPosition: 'front',
    symbolSpacing: true
  })

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
