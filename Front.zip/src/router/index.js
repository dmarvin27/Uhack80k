import Vue from 'vue'
import Router from 'vue-router'

function load (component) {
  // '@' is aliased to src/components
  return () => import(`@/${component}.vue`)
}



function load (component) {
  // '@' is aliased to src/components
  return () => import(`@/${component}.vue`)
}

Vue.use(Router)

export default new Router({
  routes: [
   
    {
      path: '/',
      name: 'login',
      component:load('components/Login')
    },
    {
      path: '/add',
      name: 'Add',
      component:load('components/Add')
    },
    {
      path: '/select',
      name: 'Select',
      component:load('components/Select')
    },
  
  ]
})
