<template>
<div>
<div class="container">

<form>
<h5 style="padding: 20px 0 10px 0">Add New Ticket</h5>
  <div class="form-group">
    <label for="exampleFormControlInput1">Title</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Enter Ticket Title here">
  </div>
    <div class="form-group">
    <label for="exampleFormControlTextarea1">Description</label>
    <textarea style="resize: none;" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
  </div>
    <div class="form-group">
    <label for="exampleFormControlInput1">Image (Optional)</label>
    <input type="file" class="form-control-file" id="exampleFormControlFile1">
  </div>
    <div class="form-group">
    <label for="exampleFormControlSelect1">Category</label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>Public Works and Highways</option>
        <option>Transportation Accessibility</option>
        <option>Calamity Aid</option>
        <option>Utility Services</option>   
        <option>Health</option>
        <option>Security</option>
    </select>
  </div>
    <div class="form-row">
    <div class="col">
          <label for="exampleFormControlSelect1">Municipal</label>
    <select class="form-control" id="exampleFormControlSelect1">
        <option>Amadeo</option>
        <option>Bacoor</option>
        <option>Cavite</option>
        <option>Imus</option>
        <option>Silang</option>
    </select>
    </div>
    <div class="col">
          <label for="exampleFormControlSelect1">Time</label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>All Day</option>
      <option>00:00</option>
      <option>01:00</option>
      <option>02:00</option>
      <option>03:00</option>
      <option>04:00</option>
      <option>05:00</option>
      <option>06:00</option>
      <option>07:00</option>
      <option>08:00</option>
      <option>09:00</option>
      <option>10:00</option>
      <option>11:00</option>
      <option>12:00</option>
      <option>13:00</option>
      <option>14:00</option>
      <option>15:00</option>
      <option>16:00</option>
      <option>17:00</option>
      <option>18:00</option>
      <option>19:00</option>
      <option>20:00</option>
      <option>21:00</option>
      <option>22:00</option>
      <option>23:00</option>
    </select>
    </div>
  </div>
</form>
<button style="margin-top: 10px;" class="btn btn-info btn-right float-right">Submit</button>
</div>
</div>

</template>
<script>


</script>

<style>
/* Made with love by Mutiullah Samim*/

@import url('https://fonts.googleapis.com/css?family=Numans');

html,body{
/*background-image: url('http://getwallpapers.com/wallpaper/full/a/5/d/544750.jpg'); */
background-size: cover;
background-repeat: no-repeat;
height: 100%;
font-family: 'Numans', sans-serif;
}

.container{
height: 100%;
align-content: center;
}

.card{
height: 370px;
margin-top: auto;
margin-bottom: auto;
 /*background-color: rgba(0,0,0,0.5) !important; */
}

.social_icon span{
font-size: 60px;
margin-left: 10px;
color: #FFC312;
}

.social_icon span:hover{
color: white;
cursor: pointer;
}

.card-header h3{
color: white;
}

.social_icon{
position: absolute;
right: 20px;
top: -45px;
}

.input-group-prepend span{
width: 50px;
background-color: #FFC312;
color: black;
border:0 !important;
}

input:focus{
outline: 0 0 0 0  !important;
box-shadow: 0 0 0 0 !important;

}

.remember{
color: white;
}

.remember input
{
width: 20px;
height: 20px;
margin-left: 15px;
margin-right: 5px;
}

.login_btn{
color: black;
background-color: #FFC312;
width: 100px;
}

.login_btn:hover{
color: black;
background-color: white;
}

.links{
color: white;
}

.links a{
margin-left: 4px;
}
</style>


