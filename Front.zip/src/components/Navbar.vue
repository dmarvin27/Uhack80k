<template>
   <div>
      <div class="container MainContainer" style="max-width: 100% !important;padding-right: 0px !important;padding-left:0px !important;">
         <!-- LEFT NAVIGATION -->
         <div class="left_navigation_wrapper" style=" border-right: 5px solid #9FCF67 !important">
            <!--logo container START-->
            <!-- <div class="logo_container">
               <router-link :to="{path: '/dashboard'}">
               </router-link>
            </div> -->
            <!-- SIDE MENU -->
            
            <div class="left_navigation_menu" >
               <ul>
                    <li  class="" >
                   
                <router-link :to="{path: '/dashboard'}" style="box-shadow: none !important;"> 
                  <img id="logo-crt" class="float-left" src="../assets/images/icon1.png" style="display: block;margin-right: auto; width:35px !important">
                </router-link>
                
                <!-- <router-link :to="{path:'/addClient'}" class="direct_btn" id="TimeKeeping_btn" style="background-color:#1AB9ED !important"> -->
                <!-- <i class="fas fa-user-plus"></i> -->
                <!-- <span id="LMSpan" class="ButtonLabel" >Add Client</span> -->
                <!-- </router-link> -->
                </li>
                  <li id="TKeep" class="">
                     <router-link :to="{path:'/trackCompletion'}" class="direct_btn" id="trackCompletion" style="background-color:#1AB9ED">
                        <i class="far fa-list-alt"></i>
                        <span id="LMSpan" class="ButtonLabel">   Track Completion</span>
                     </router-link>
                  </li>
                  <li id="LManage" class="accessbtn">
                     <router-link :to="{path: '/users'}" class="direct_btn" id="users" style="background-color:#9FCF67" >
                        <i class="fas fa-users"></i>
                        <span id="LMSpan" class="ButtonLabel">Users</span>
                     </router-link>
                  </li>
                  <li id="LManage" class="accessbtn">
                     <router-link :to="{path: '/crtSettings'}" class="direct_btn" id="crtSettings"  style="background-color:#A66BD3" >
                        <i class="fas fa-cogs"></i>
                        <span id="LMSpan" class="ButtonLabel">CRT Settings</span>
                     </router-link>
                  </li>
               </ul>
            </div>
            <!-- END SIDE MENU -->
            
         </div>
         <!-- END LEFT NAVIGATION -->
         <div class="main_container_wrapper" style="padding-right: 0px !important;">
            <!-- TOP NAVIGATION -->
            <div class="top_navigation_wrapper" style="background-color:#2E75B6">
               <div class="breadcrumb_container">
                  <div>
                     <i style="margin: 10px 15px 0px 0px" class="fas fa-user fa-2x" aria-hidden="true"></i>
                     </div>
                  <div class="breadcrumbs"> 
                     <div class="AliasContainer">    
                        <div>   
                       <p id="profname" style="padding-top: 6px;">{{ fullName }}</p>     <!--{{ EmployeeProfile.Alias }} -->
                       <p style="font-size: 11px;">{{ email }}</p>
                        </div> 
                                                
                     </div>
                     <div class="marqueeContainer" id="UpdatePanel4">
                     </div>
                  </div>
               </div>
               <div class="top_navigation_menu" >
                  <ul class="top_icon_menu" style="margin-left:75% !important;" >
                     <li   style=" color:#FFFFF !important;"  > 
                        <!-- <a href='#'>  -->
                         <label id="logout" @click=logoutModal()>  Log out</label>
                       
                      
                        <!-- <i class="fas fa-sign-out-alt fa-lg" ></i> -->
                        <!-- </a>  -->
                     </li>
                  </ul>
               </div>
            </div>
            <!-- END TOP NAVIGATION -->
            <div class="main_body_wrapper">
            </div>
            
         </div>
      </div>
        <div style="margin-left:30%;" v-show ="showLogoutModal" >
         <div class="modal_box modal_SM" style="z-index:3;margin-top:3%; text-align: center;border-radius: 5px">
            <div class="modal_title">
               <label for="">Confirmation: Log-out</label>
               <a href="#" class="modal_close_btn" @click="showLogoutModal = !showLogoutModal ">&times;</a>
            </div>
            <div class="col-md-12" style="margin-top:13% !important;">
                  <p class="form-label">Are you sure you want to log-out?</p>
            </div>
            <div class="col-md-12" style="bottom: -30%; position: relative;">
               <button type="button" class="btn btn-success" @click="logout()" style="margin-right:40px; border-radius: 25px;padding: 5px 15px 5px 15px;"><span class="glyphicon glyphicon-ok"></span> Confirm</button>
               <button type="button" class="btn btn-danger" style="border-radius: 25px;padding: 5px 15px 5px 15px;" @click="showLogoutModal = !showLogoutModal"><span style="margin-top: 3px !important;" class="glyphicon glyphicon-remove"></span> Cancel</button>
            </div>
         </div>
      </div>
       <div style="margin-left:30%;" v-show ="showLogoutModal" >
         <div class="modal_box modal_SM" style="margin-top:3%; text-align: center;border-radius: 5px">
            <div class="modal_title">
               <label for="">Confirmation: Log-out</label>
               <a href="#" class="modal_close_btn" @click="showLogoutModal = !showLogoutModal ">&times;</a>
            </div>
            <div class="col-md-12" style="margin-top:13% !important;">
                  <p class="form-label">Are you sure you want to log-out?</p>
            </div>
            <div class="col-md-12" style="bottom: -30%; position: relative;">
               <button type="button" class="btn btn-success" @click="logout()" style="margin-right:40px; border-radius: 25px;padding: 5px 15px 5px 15px;"><span class="glyphicon glyphicon-ok"></span> Confirm</button>
               <button type="button" class="btn btn-danger" style="border-radius: 25px;padding: 5px 15px 5px 15px;" @click="showLogoutModal = !showLogoutModal"><span style="margin-top: 3px !important;" class="glyphicon glyphicon-remove"></span> Cancel</button>
            </div>
         </div>
      </div>
   </div>
</template>

<script>
   import axios from 'axios'
   import login from './Login'
   import router from '../router'
   import dashboard from './Dashboard'
   export default {
       data () {
           return {
               fullName: '',
               email: '',
               breakSubMenu: false,
               showRight: true,
               profSideBar: false,
               MCSideBar: false,
               TDSideBar: false,
               RFSideBar: false,
               CBSideBar: false,
               showLogoutModal: false,
               access: [],
               EmployeeProfile: [],
               showLogoutModal: false
           }
       },

   created(){
        //  axios.post(this.$localStorage.get("URL")+'CRT_ShowFullNameAndEmail',{
        //      UserName: this.$localStorage.get('userName')
        //     //  UserName: "i002"
        //  })
        //  .then(response => { 
        // //  this.fullName = response.data[0]['FullName'];
        // //  this.email = response.data[0]['Email'];
        //   }, (error) => { console.log(error) })

      
   },
   
   methods: {
       
       logoutModal(){
            this.showLogoutModal = true;
        },
       
       logout(){
           this.$router.push('/');
           this.$localStorage.remove('userName')
           this.$localStorage.set('authenticated', false)
       }
   }
   }
</script>
<style scoped>
   a:hover { 
   cursor: pointer; 
   }
   .disabled{
   color:grey;
   text-decoration:none;
   cursor:default !important;
   }
   #logout{
      font-weight:500
   }
   #logout:hover{
      border-bottom:0.5px solid white
   }
</style>