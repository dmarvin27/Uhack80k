<template>
<div>
 <navbar v-show='navbar'></navbar>
<div v-show='navbar'>
    <div class="container MainContainer" style="max-width: 100% !important;padding-right: 0px !important;padding-left:70px !important;">
        <div class="col-sm-12" style="width:100%;">
            <h1>Dashboard</h1>
        </div>
           
        </div>
         <div class=" container col-sm-12"  style="max-width: 100% !important;padding-right: 20px !important;padding-left:70px !important;">
             <div class="col-sm-3">
                <div class="card text-white" style="height:108px; padding:15px; color:white; border-radius: 10px; background: linear-gradient(to top right, #1a237e 50%, #5c6bc0 100%);">
                     <div class="col-md-12">
                       <div class="card-body" style="font-size: 80%;">Total Upload </div>
                        <div class="col-md-8">
                          
                          <div class="card-body" style="font-size: 320%;">{{upload | currency}}</div>
                        </div>
                         <div class="col-md-3">
                            <div><i class="far fa-arrow-alt-circle-up fa-7x"></i></div>
                        </div>
                    </div>
                </div>
             </div>
              <div class="col-sm-3">
                <div class="card text-white" style="height:108px; padding:15px; color:white; border-radius: 10px; background: linear-gradient(to top right, #00b0ff 70%, #40c4ff 100%);">
                    <div class="col-md-12">
                      <div class="card-body" style="font-size: 80%; ">Complete Data Entry (<b>{{roundedcomplete}}%</b>)</div>
                        <div class="col-md-8">
                            
                            <div class="card-body" style="font-size: 320%; ">{{complete | currency}}</div>
                        </div>
                         <div class="col-md-3">
                            <div><i class="far fa-check-circle fa-7x"></i></div>
                        </div>
                    </div>
                </div>
             </div>
             <div class="col-sm-3">
                 <div class="card text-white" style="height:108px; padding:15px; color:white; border-radius: 10px; background: linear-gradient(to top right, #ef5350 0%, #c62828 100%);">
                    <div class="col-md-12">
                      <div class="card-body" style="font-size: 80%; ">Incomplete Data Entry (<b>{{roundedincomplete}}%</b>)</div>
                        <div class="col-md-8">
                             <div class="card-body" style="font-size: 320%; ">{{incomplete | currency}}</div>
                        </div>
                         <div class="col-md-3">
                            <div><i class="fas fa-ban fa-7x"></i></div>
                        </div>
                    </div>
                </div>
             </div>
              <div class="col-sm-3">
                 <div class="card text-white" style="height:108px; padding:15px; color:white; border-radius: 10px; background: linear-gradient(to top right, #64dd17 0%, #76ff03 100%);">
                    <div class="col-md-12">
                      <div class="card-body" style="font-size: 80%; ">CRT Generated</div>
                        <div class="col-md-8">
                             <div class="card-body" style="font-size: 320%; ">{{generated | currency}}</div>
                        </div>
                         <div class="col-md-3"> 
                            <div><i class="far fa-arrow-alt-circle-down fa-7x"></i></div>
                        </div>
                    </div>
                </div>
             </div>
             <!-- bottom -->  
             <!-- <div class="col-md-8" style="max-width: 100%; height:50%; margin-left:0% !important;">
                <div class="content_panel" style="height:50vh">
                  <div class="col-md-12">
                    </br>
                    </br>
                    <div class="col-md-4">
                      <div id="chart">
                        <apexchart type=line width=300 :options="chartOptions" :series="series" />
                      </div>
                    </div>
                    <div div class="col-md-1">
                    </div>
                    <div class="col-md-7">
                      <div id="chart">
                        <apexchart ref ="pie" type=pie width=400 :options="chartOptionsPIE" :series="seriespie" />
                      </div>
                    </div>
                  </div>
                </div>
             </div> -->
             <!-- Table -->
              <!-- <div class="col-md-4" style="max-width: 100%; height:50%; margin-left:0% !important;"> -->
             <div class="col-md-12" style="max-width: 100%; height:50%; margin-left:0% !important;">
                    <div class="content_panel" style="height:50vh">
                        <div class="content_title2 MC" style="background-color:#7030A0 !important; z-index:2; color:white">
                        <label style="color:white !important">Site List</label>
                        </div>
                        <div class="content_body2 body-height" style="overflow-y: auto;  !important;">
                          <table class="content_table" >
                              <thead>
                              <tr>
                                  <th>Sites</th>
                                  <th>Complete</th>
                                  <th>Incomplete</th>
                              </tr>
                              </thead>
                              <tbody>
                                <tr v-for="value in value">
                                <td ><div style="text-align: center;"><label>{{value.Branch}}</label></div></td>
                                <td ><div style="text-align: center;"><label @click="ClickComplete(value)" style="text-align: center;">{{value.Complete}}</label></div></td>
                                <td ><div style="text-align: center;"><label @click="ClickIncomplete(value)" style="text-align: center;">{{value.Incomplete}}</label></div></td>
                                </tr>
                              </tbody>
                          </table>
                        </div>
                    </div>
                </div>
          </div>
        </div>

           <!-- // modal for change password --> 

                   <div style="margin-left:30%;" v-show ="forgotPassword3" >
         <div class="modal_box modal_SM" style="z-index:3;margin-top:3%; text-align: center;border-radius: 5px; height:250px !important;">
            <div class="modal_title">
               <label for="">Change Password</label>
               <!-- <a href="#" class="modal_close_btn" @click="forgotPassword3 = !forgotPassword3 ">&times;</a> -->
            </div>
            <div class="col-md-12" style="margin-top:8% !important;">
                 <p >Please enter your new password</p>
                  <input :type="recoveryField" v-model="enteredPassword" style="height:30px !important;width:170px !important">
                  <br>
                 <input type="checkbox" style="margin-bottom:20px;" @click="showPass()" > &nbsp;Show Password<br>
            </div>
            <div class="col-md-12" style=";position:relative">
               <button type="button" class="btn btn-success" @click="changePassword()" style="margin-right:23px; border-radius: 25px;padding: 5px 15px 5px 15px;"><span class="glyphicon glyphicon-ok"></span> Confirm</button>
               <!-- <button type="button" class="btn btn-danger" style="border-radius: 25px;padding: 5px 15px 5px 15px;" @click="showLogoutModal = !showLogoutModal"><span style="margin-top: 3px !important;" class="glyphicon glyphicon-remove"></span> Cancel</button> -->
            </div>
         </div>
      </div>
           <!-- end of change password modal -->
</div> 
</template>
<script>
   import Navbar from './Navbar'
   import Login from './Login'
   export default {
       components: {
           Navbar,
           Login
       },
       data(){
           return{
              value:[],
              upload:'',
              forgotPassword3:false,
              enteredPassword:'',
              recoveryField:'password',
              showPassword:true,
              navbar:false,
              dashboard:true
           }
       },
        created () {
           if (localStorage.getItem('authenticated') !== 'true') {
               this.$router.push('/')
               }
               else {
               this.$router.push('/dashboard')
               }
               this.isPasswordDefault();
            //    this.testing()
            this.displayList();
          this.displayCounts();
          
       },
      //  mounted() {
      //   this.displayList();
      // },
       methods:{
         ClickComplete(val)
    {
      console.log(val)
      axios.post(this.$localStorage.get("URL")+'ExtractDataDashboard',{
                CN: localStorage.getItem("company"),
                Site:val.Branch,
                Result:'Complete'
            }).then(
              response => {
                window.open(response.data)
              },
              error => {
                console.log(error);
              }
            );
    },
    ClickIncomplete(val)
    {
      console.log(val)
      axios.post(this.$localStorage.get("URL")+'ExtractDataDashboard',{
                CN: localStorage.getItem("company"),
                Site:val.Branch,
                Result:'Incomplete'
            }).then(
              response => {
                window.open(response.data)
              },
              error => {
                console.log(error);
              }
            );
    },
       displayCounts(){
        axios.post(this.$localStorage.get("URL")+'DashboardCount',{
          CN: localStorage.getItem("company")
                //CompanyAlias:this.lastAlias
            }).then(response=>{
                console.log(response.data.DisplayTotalCount)
                this.repValue = response.data
                this.upload =  response.data.DisplayTotalCount[0].TotalUpload
                this.complete =  response.data.DisplayTotalCount[0].CompleteDataEntry
                this.incomplete =  response.data.DisplayTotalCount[0].IncompleteDataEntry
                this.generated =  response.data.DisplayTotalCount[0].CRTGenerated
                this.roundedcomplete =  response.data.DisplayTotalCount[0].RoundedComplete
                this.roundedincomplete =  response.data.DisplayTotalCount[0].RoundedIncomplete
                console.log(this.upload)
                //   window.open(response.data)
            })
        },
    addClient() {
      this.$router.push("/addClient");
    },
    listClient() {
      this.$router.push("/listClient");
    },
    displayList(){
      axios.post(this.$localStorage.get("URL")+'GetAllClientDashboard', { 
        CN: localStorage.getItem("company")
        // CN:localStorage.getItem('company'),
        // CClientID: this.$localStorage.get('cClientID')
         }).then(response => {
        //console.log(this.chartOptionsPIE.labels + "asds");
        //console.log(this.seriespie);
        this.value=response.data.Clientdetails;
        // var i;
        // var x;
        // for (i = 0; i < this.value.length; i++) {
        //   this.pieList.push(response.data.Clientdetails[i].Branch)
        // }
        // for (x = 0; x < this.value.length; x++) {
        //   this.piegraph.push(response.data.Clientdetails[x].Complete)
        // }
        // this.$refs.pie.updateOptions({
        //   labels: this.pieList
        // });
      }, (error) => { console.log(error) })
    },
            showPass(){
                this.recoveryField = this.recoveryField === 'password' ? 'text' : 'password'
          },
           isPasswordDefault(){
               console.log(localStorage.getItem('userName'))
            //    alert("if defaultPass is true then show forgotpassword modal else navbar=true");
                axios.post(this.$localStorage.get("URL")+'CRT_CheckPasswordDefaultv3', { 
                UserName:localStorage.getItem('userName'),
                CompanyAlias:localStorage.getItem('company')
                }).then(response => { 
                    console.log(response.data)
                    if(response.data == 'False'){
                        this.forgotPassword3 = !this.forgotPassword3
                    }else{
                        this.navbar = true
                        this.dashboard = true
                    }
         }, (error) => { console.log(error) })
    
             
           },
           changePassword(){
               //Min 8, alpha numeric, 1 special character
               //hahaha
function checkPassword(str)
{
    var result = str.replace(/[^a-zA-Z0-9-]/g, "");
    return  result
}
               if(this.enteredPassword.length>=8 && this.enteredPassword.length<=15){
if(checkPassword(this.enteredPassword).length!=this.enteredPassword.length)
{
    axios.post(this.$localStorage.get("URL")+'CRT_UpdatePasswordUserNamev2', { 
                 UserName:localStorage.getItem('userName'),
                 Password:this.enteredPassword
                }).then(response => { 
                    console.log(response.data)
                    if(response.data == 'success'){
                  this.$toastr.success('Password has been successfully changed.', 'Success', {positionClass: 'toast-bottom-right'}) 
               
                        this.$router.push('/');
                        this.$localStorage.remove('userName')
                        this.$localStorage.set('authenticated', false)

                    }else{
                        // this.navbar = true
                    }
         }, (error) => { console.log(error) })
}
else{
      this.$toastr.warning('The Password must be minimum of 8 and maximum of 15 characters, also it should have atleast 1 special character', 'Warning', {positionClass: 'toast-bottom-right'}) 
}

            //    axios.post(this.$localStorage.get('URL'+'CRT_UpdatePasswordUserName',{
            //        UserName:localStorage.getItem('userName'),
            //        Password:this.enteredPassword
            //    })).then(res=>{
            //        console.log(res)
            //         if(res.data='success'){
            //            this.$toastr.success('Password has been successfully changed.', 'success', {positionClass: 'toast-bottom-right'}) 
            //             this.forgotPassword3=false;
            //             this.navbar = true
            //         }
            //    })


               }
               else{
                   
        //  this.$toastr.success('Password has been successfully changed.', 'success', {positionClass: 'toast-bottom-right'}) 
               
              this.$toastr.warning('The Password must be minimum of 8 and maximum of 15 characters, also it should have atleast 1 special character', 'Warning', {positionClass: 'toast-bottom-right'}) 
                
               }
                
           },
        //    testing(){
        //        alert(localStorage.getItem('company'))
        //    },
           addClient(){
               this.$router.push('/addClient');
           },
            listClient(){
               this.$router.push('/listClient');
           },
           
       }
   }
</script>
<style scoped>
   #home {
   /* background-color: #093A4B; */
   background-image: url("../assets/images/bg2.png");
   padding-bottom:5%;
   background-position: center;
   background-repeat: no-repeat;
   background-size: cover;
   height: 100%;
   top: 0;
   left: 0;
   bottom: 0;
   right: 0;
   position: fixed;
   }
   .menu{
   background-image: url("../assets/images/list.png");
   background-position: center;
   background-repeat: no-repeat;
   background-size: cover;
   margin-left: 45%;
   width:16%;
   height: 65%;
   transform: skew(-10deg);
   background-color: #9FCF67;
   border: none;
   }
   #add-client{
   background-image: url("../assets/images/addclient.png") !important;
   bottom: 0;
   background-position: top !important;
   height: 55% !important;
   margin-left: 60% !important;
   position: fixed !important;
   background-color: #1AB7EA !important;
   z-index: 1;
   }
   #tabledata{
   text-align:center !important;
   }
   .fmemail {
   text-align: center;
   }
   /* @import url(https://fonts.googleapis.com/css?family=Roboto);

   body {
     font-family: Roboto, sans-serif;
   } */
   #chart {
   max-width: 650px;
   margin: 35px auto;
   } 
</style>

