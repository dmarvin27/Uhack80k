var Loader = $("#background-loader");


function load(file) {
    var iframe = document.getElementById('main_iframe');

    setTimeout(function () {
        iframe.src = file + "?autoplay=1";
     }, 600);
}

$("a.direct_btn").click(function(){ 


    if($("a.direct_btn").hasClass("buttonLoad")){
       $("a.direct_btn").removeClass("buttonLoad");
    }
    
    if($("a.sidebar_btn").hasClass("buttonCollapse")){
       $("a.sidebar_btn").removeClass("buttonCollapse");
    }

    $(this).addClass("buttonLoad");
    $(Loader).fadeIn();
    $(".SideBar_Menu").removeClass("Active_SideBar");

});

$("a.direct_btn i span").click(function () {


    if ($("a.direct_btn").hasClass("buttonLoad")) {
        $("a.direct_btn").removeClass("buttonLoad");
    }

    if ($("a.sidebar_btn").hasClass("buttonCollapse")) {
        $("a.sidebar_btn").removeClass("buttonCollapse");
    }

    $(".SideBar_Menu").removeClass("Active_SideBar");
    $(".SideBar_Overlay").removeClass("Active_SideBar");

});


$("a.sidebar_btn").click(function(){


    if($("a.direct_btn").hasClass("buttonLoad")){
       $("a.direct_btn").removeClass("buttonLoad");
    }
    
    if($("a.sidebar_btn").hasClass("buttonCollapse")){
       $("a.sidebar_btn").removeClass("buttonCollapse");
    }
    
    $(this).addClass("buttonCollapse");
    

});




$(".SideBar_Overlay").click(function () {
    setTimeout(function() {
        $(".SideBar_Menu").removeClass("Active_SideBar");

    }, 250);

    $(".SideBar_Overlay").removeClass("Active_SideBar");
    $("a.sidebar_btn").removeClass("buttonCollapse");
});





//Breakbutton
$("#break_btn").click(function(){
    $("ul.break_submenu").stop().slideToggle();
    e.stopPropagation();
});

$("ul.break_submenu li").click(function () {
   $(this).parent("ul.break_submenu").stop().slideUp(); 
});


$(".breadcrumb_container, .left_navigation_wrapper, .content_panel").click(function (){
    $("ul.break_submenu").stop().slideUp();
});

$(".top_navigation_wrapper, .logo_container").click(function () {

    $(".SideBar_Menu").removeClass("Active_SideBar");
    $(".SideBar_Overlay").removeClass("Active_SideBar");
    $("a.sidebar_btn").removeClass("buttonCollapse");

});

//Trigger SideBar Menus
$(document).on("click", ".sidebar_btn", function () {
    
    var SideBarID = $(this).attr("href");
    
    if($(SideBarID).hasClass("Active_SideBar")) {
        SideBarHide();
        $(this).removeClass("buttonCollapse");
    }
    
    else {
        $(".SideBar_Menu").siblings().removeClass("Active_SideBar");
        $(SideBarID).addClass("Active_SideBar");
        SideBarOverlay();
        $(this).removeClass("buttonCollapse");
    }
     
    
});

function SideBarOverlay() {
    
    $(".sideBar_Overlay").addClass("Active_SideBar");
}

function SideBarHide() {
    $(".SideBar_Menu").removeClass("Active_SideBar");
    $(".sideBar_Overlay").removeClass("Active_SideBar");
}

$(".SideBar_Menu").on("click", "a", function () {
   
    
    if($(this).hasClass("submenu_btn")) {
        $(this).parent().find("ul.SideBar_SubMenu").stop().slideToggle();
    }

    else if($(this).parent('[class*="TreeView"]')) {
       
    }
    
    else {
        SideBarHide();
    }
    
});





//Submenu Buttons
$(".SubMenu_btn").click(function () {

    $(this).next('.SideBar_SubMenu').slideToggle();
    $(this).parent().siblings().children().next().slideUp();
    return false;
});

$(".SideBar_SubMenu a").click(function () {
    $(".SideBar_Menu").removeClass("Active_SideBar");
    $(".SideBar_Overlay").removeClass("Active_SideBar");
    $("a.sidebar_btn").removeClass("buttonCollapse");
});

$(".SideBar_Menu .direct_sub").click (function () {
    $(".SideBar_Menu").removeClass("Active_SideBar");
    $(".SideBar_Overlay").removeClass("Active_SideBar");
    $("a.sidebar_btn").removeClass("buttonCollapse");
});

$("#ProfID, #MasterCntrl, #TodoSub").click(function () {
   $(".SideBar_Menu").removeClass("Active_SideBar");
    $(".SideBar_Overlay").removeClass("Active_SideBar");
    $("a.sidebar_btn").removeClass("buttonCollapse");
});



$(window).click(function() {
    $(".top_submenu").removeClass("show");
});

function iframeLoaded() {
    $("a.buttonLoad").removeClass("buttonLoad");
}

/* Close Modal */
$(".modal_close_btn").click(function () {
    $(".modal_container").addClass("out");

    setTimeout(function () {
        $(".modal_container").removeClass("active");
        $(".modal_container").removeClass("out");
    }, 500);

});

var LeftNavWrap = $(".left_navigation_wrapper");
var SideBarBTN = $(".sidebar_btn");

$(LeftNavWrap).hover(function (){
    $(this).addClass("active");
    $(this).mouseleave(function (){
       $(this).removeClass("active"); 
    });
});

$(SideBarBTN).click(function () {
    
    $(LeftNavWrap).removeClass("active");
});

/* Responsive Menu* */  
var topBurgerMenu = $(".topBurgerMenu");
var topIconMenu = $(".top_icon_menu");

$(topBurgerMenu).click(function () {
    
    $(topBurgerMenu).stop().toggleClass("active");
    
   
    
    $(topIconMenu).slideToggle(function () {
        if ($(this).css('display') == 'block') $(this).css('display', 'flex');
    });
    return false;
});

/*Screen size change*/
$(window).resize(function() {
    if (document.documentElement.clientWidth > 700) {
        $(topIconMenu).css("display", "flex");
    }
    
     if ($(topIconMenu).is(":visible")) {
        $(topBurgerMenu).addClass("active");
    }
    
}).resize()



