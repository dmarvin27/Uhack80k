import {router} from '../router'
import axios from 'axios'
const API_URL = 'http://192.168.2.33:82/'
// const LOGIN_URL = API_URL + 'Login'
// const SIGNUP_URL = API_URL + 'users/'

export default {
  user: {
    authenticated: false,
    EmpID: ''
  },

  login (context, creds, redirect) {
    if (creds.username === '' && creds.password === '')
    {
      this.$toastr.error('Please input username and password.', 'Error')
    }
    else if (creds.username === '')
    {
      this.$toastr.error('Please input username.', 'Error')
    }
    else if (creds.password === '')
    {
      this.$toastr.error('Please input password.', 'Error')
    }
    else{
      axios.post(API_URL + 'CRTLogin', {cn:this.company,userid:this.username,pass:this.password}).then(response => {
        console.log(response.data)
        if (response.data === 'True')
        {
          localStorage.setItem('userName', creds.username)
          localStorage.setItem('authenticated', true)
          router.push(redirect)
          this.$toastr.success('Sucessfully login.', 'Success')
        }
        else
        {
          this.$toastr.error('Invalid Username or Password.', 'Error')
        }
      }, (error) => {
        console.log(error)
      })

    }
  },
  logout () {
    localStorage.removeItem('userName')
  localStorage.setItem('authenticated', false)
  router.push('/')
},

checkAuth () {
    var jwt = localStorage.getItem('id_token')
    if (jwt) {
      this.user.EmpID = jwt
      this.user.authenticated = true
    }
    else {
      this.user.EmpID = ''
      this.user.authenticated = false
    }
  },
  getAuthHeader () {
    return {
      'Authorization': 'Bearer ' + localStorage.getItem('access_token')
    }
  }
}

